sap.ui.define(
    ['sap/fe/AppComponent'],
    ac => ac.extend('timetracking.Component', {
        metadata: {
            manifest: 'json'
        }
    })
)